package com.ahmed.dailyrevenue;

import android.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;
import android.view.Gravity;
import android.text.InputType;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.util.concurrent.Executor;

public class MainActivity extends FragmentActivity {
    private WebView webView;
    private boolean unlocked = false;
    private boolean authInProgress = false;
    private boolean lockUiShowing = false;
    private static final String PREFS = "my_revenue_security";
    private static final String PIN_HASH = "pin_hash";
    private static final String PIN_SALT = "pin_salt";
    private static final String BIO_ENABLED = "biometric_enabled";

    public class AndroidSecurity {
        @JavascriptInterface public void changePin() {
            runOnUiThread(() -> showChangePinDialog());
        }
    }

    public class AndroidShare {
        @JavascriptInterface public void shareFile(String base64, String mime, String name) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "shared");
                    if (!dir.exists()) dir.mkdirs();
                    File file = new File(dir, name.replaceAll("[^a-zA-Z0-9._-]", "_"));
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".provider", file);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime); send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "مشاركة تقرير My Revenue"));
                } catch (Exception e) { Toast.makeText(MainActivity.this, "تعذر تجهيز الملف للمشاركة", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,20,20));
        getWindow().setNavigationBarColor(Color.rgb(16,20,20));
        createWebView();
        showGate();
    }

    private void createWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16,20,20));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true); settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true); settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new AndroidShare(), "AndroidShare");
        webView.addJavascriptInterface(new AndroidSecurity(), "AndroidSecurity");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasPin() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).contains(PIN_HASH);
    }

    private void showGate() {
        if (isFinishing() || lockUiShowing) return;
        lockUiShowing = true;
        if (!hasPin()) showCreatePinDialog();
        else if (canUseBiometric()) showBiometricPrompt();
        else showPinDialog();
    }

    private void showCreatePinDialog() {
        LinearLayout box = dialogBox();
        TextView title = dialogTitle("إنشاء رمز حماية My Revenue");
        EditText first = pinField("أنشئ رمزاً سرياً من 6 أرقام");
        EditText second = pinField("أعد كتابة الرمز للتأكيد");
        box.addView(title); box.addView(first); box.addView(second);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(box)
                .setCancelable(false).setPositiveButton("حفظ الرمز", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            String a = first.getText().toString(), b = second.getText().toString();
            if (!a.matches("[0-9]{6}")) { first.setError("الرمز يجب أن يتكون من 6 أرقام"); return; }
            if (!a.equals(b)) { second.setError("الرمزان غير متطابقين"); return; }
            storePin(a);
            boolean bio = canUseBiometric();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(BIO_ENABLED, bio).apply();
            dialog.dismiss(); lockUiShowing = false; unlockApp();
            if (bio) Toast.makeText(this, "تم تفعيل البصمة مع إمكانية استخدام الرمز السري", Toast.LENGTH_LONG).show();
            else Toast.makeText(this, "تم إعداد الرمز السري. البصمة غير متاحة حالياً على الجهاز", Toast.LENGTH_LONG).show();
        }));
        dialog.show();
    }

    private void showPinDialog() {
        if (isFinishing()) return;
        LinearLayout box = dialogBox();
        TextView title = dialogTitle("My Revenue محمي");
        TextView subtitle = new TextView(this); subtitle.setText("أدخل رمز الحماية المكوّن من 6 أرقام للمتابعة");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setPadding(0, 0, 0, 18);
        EditText pin = pinField("الرمز السري");
        box.addView(title); box.addView(subtitle); box.addView(pin);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(box)
                .setCancelable(false).setPositiveButton("فتح التطبيق", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            if (verifyPin(pin.getText().toString())) {
                dialog.dismiss(); lockUiShowing = false; unlockApp();
            } else { pin.setText(""); pin.setError("الرمز غير صحيح"); }
        }));
        dialog.show();
    }

    private LinearLayout dialogBox() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(22 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad); return box;
    }
    private TextView dialogTitle(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(20);
        t.setTextColor(Color.rgb(30,150,95)); t.setGravity(Gravity.CENTER);
        t.setPadding(0,0,0,18); return t;
    }
    private EditText pinField(String hint) {
        EditText e = new EditText(this); e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setSingleLine(true); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        e.setPadding(18,14,18,14); return e;
    }

    private void showChangePinDialog() {
        LinearLayout box = dialogBox();
        TextView title = dialogTitle("تغيير رمز الحماية");
        EditText oldPin = pinField("الرمز الحالي");
        EditText newPin = pinField("الرمز الجديد - 6 أرقام");
        EditText confirm = pinField("تأكيد الرمز الجديد");
        box.addView(title); box.addView(oldPin); box.addView(newPin); box.addView(confirm);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(box)
                .setCancelable(true).setPositiveButton("حفظ", null).setNegativeButton("إلغاء", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            String old = oldPin.getText().toString(), next = newPin.getText().toString();
            if (!verifyPin(old)) { oldPin.setError("الرمز الحالي غير صحيح"); return; }
            if (!next.matches("[0-9]{6}")) { newPin.setError("استخدم 6 أرقام"); return; }
            if (!next.equals(confirm.getText().toString())) { confirm.setError("الرمزان غير متطابقين"); return; }
            storePin(next); dialog.dismiss();
            Toast.makeText(this, "تم تغيير رمز الحماية", Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }

    private void storePin(String pin) {
        try {
            byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
            byte[] hash = derive(pin.toCharArray(), salt);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString(PIN_HASH, Base64.encodeToString(hash, Base64.NO_WRAP)).apply();
        } catch (Exception e) { Toast.makeText(this, "تعذر حفظ رمز الحماية", Toast.LENGTH_LONG).show(); }
    }
    private boolean verifyPin(String pin) {
        if (pin == null || !pin.matches("[0-9]{6}")) return false;
        try {
            android.content.SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            byte[] salt = Base64.decode(p.getString(PIN_SALT, ""), Base64.DEFAULT);
            byte[] expected = Base64.decode(p.getString(PIN_HASH, ""), Base64.DEFAULT);
            return MessageDigest.isEqual(expected, derive(pin.toCharArray(), salt));
        } catch (Exception e) { return false; }
    }
    private byte[] derive(char[] pin, byte[] salt) throws Exception {
        KeySpec spec = new PBEKeySpec(pin, salt, 150000, 256);
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    }

    private boolean canUseBiometric() {
        return BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                == BiometricManager.BIOMETRIC_SUCCESS;
    }
    private void showBiometricPrompt() {
        if (isFinishing() || authInProgress) return;
        authInProgress = true;
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authInProgress = false; lockUiShowing = false; unlockApp();
            }
            @Override public void onAuthenticationError(int code, CharSequence message) {
                authInProgress = false;
                if (code != BiometricPrompt.ERROR_NEGATIVE_BUTTON && code != BiometricPrompt.ERROR_USER_CANCELED) {
                    Toast.makeText(MainActivity.this, "استخدم الرمز السري للمتابعة", Toast.LENGTH_SHORT).show();
                }
                lockUiShowing = false; showPinDialog();
            }
            @Override public void onAuthenticationFailed() {
                Toast.makeText(MainActivity.this, "لم يتم التعرف على البصمة، حاول مرة أخرى أو استخدم الرمز", Toast.LENGTH_SHORT).show();
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("فتح My Revenue")
                .setSubtitle("أكد هويتك باستخدام بصمة الإصبع")
                .setNegativeButtonText("استخدام الرمز السري")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .build();
        prompt.authenticate(info);
    }

    private void unlockApp() {
        unlocked = true; setContentView(webView);
    }
    @Override protected void onStop() {
        super.onStop();
        if (unlocked && !authInProgress) unlocked = false;
    }
    @Override protected void onStart() {
        super.onStart();
        if (webView != null && !unlocked && hasPin()) {
            lockUiShowing = false;
            webView.setVisibility(WebView.INVISIBLE);
            showGate();
        }
    }
    @Override public void onBackPressed() {
        if (!unlocked) return;
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
